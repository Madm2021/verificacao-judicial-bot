gunicorn verificacao_judicial_bot:app --bind 0.0.0.0:$PORT
